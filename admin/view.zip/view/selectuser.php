
<section class="animate__animated animate__fadeIn">
    <p class="page-title">
        <span>Select user</span>
    </p>
    <div >
        <div class="table-content">
            <table>
                <thead>
                    <tr>
                        <th>s/n </th>
                        <th>First name</th>
                        <th>last name</th>
                        <th>othernames</th>
                        <th>email</th>
                        <th>address</th>
                        <th>status</th>
                        <th>action</th>
                    </tr>
                </thead>
                <tbody id="tabledata">
                   <tr>
                        <td colspan="100%" class="text-center opacity-70"> Table is empty</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="table-status"></div>
    </div>

</section>
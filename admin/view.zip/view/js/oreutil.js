function validateForm(formm, ids=null) {
    let form = document.getElementById(formm)
    let errorElements = form.querySelectorAll('.control-error')
    let controls = [] 
    
    if(ids){
        for(let i=0;i<ids.length;i++){
            if(controlHasValue(form, `#${ids[i]}`))controls.push([form.querySelector(`#${ids[i]}`), `${form.querySelector(`#${ids[i]}`).previousElementSibling.textContent ? form.querySelector(`#${ids[i]}`).previousElementSibling.textContent : ids[i]} is required`])
        }
    }
    
    return mapValidationErrors(errorElements, controls)   

}

const callController =(controller, params, name, validate, funct, silent, e)=>{ 
    silent ? null : showSpinner();
    if(validate){
        if(!validateInputsComponent(validate)){ 
		hideSpinner();
		return null; 
		}
    }
    var request = getAjaxObject();
    request.open('POST',`../controllers/${controller}`,true);
    request.onreadystatechange = function(){
        if(request.readyState == 1){
        }
        if(request.readyState == 4 && request.status == 200){
            hideSpinner();
                // console.log(`controller request.responseText ${name}:`, request.responseText)
                let result = JSON.parse(request.responseText); 
                //console.log(result);
                if(result["code"] == "invalid session data. Proceed to login"){
                    // window.location.href = "login.php";
                    return;
                }
                if(result["message"] == "invalid session data. Proceed to login"){
                    // window.location.href = "login.php";
                    return;
                }
                if(result["result"] === "ERROR"){
                    // console.log(`contrlr status ${name}: ERROR`);
                    callModal(`Failed: ${result.message ? result.message : ''}`, 0);
                    return null;
                }else{
                    // console.log(`controller ${controller}`, result, 'NB: result returned','name', `${name}`);
                    if(!silent){
                        if(result.message == 'Successful'){
                            callModal(`${result.message ? result.message : 'Successful'}`, 1)
                        }else{
                            callModal(`${result.message ? result.message : 'Successful'}`, 2)
                        }
                    }
                    //console.log(funct)
                    if(funct){
                        return funct(result);
                    } 
                }
        }else{
            hideSpinner();
        }
        try{
            e.stopPropagation();
        }catch(ex){}
    };
    if(params != null){
            //   console.log(name, 'PARAMS BELOW');    
        for (var pair of params.entries()) {
            //   console.log(pair[0] + ', ' + pair[1]);   
            // return(name, pair[0]+ ', ' + pair[1]); 
            }
    }
    
    request.setRequestHeader('Connection','close');
    request.send(params);
};

function previewImage(img="url") {
        var input = document.getElementById(`${img}`);
        var preview = document.getElementById('imagePreview');

        // Clear previous preview
        preview.innerHTML = '';

        // Check if any file is selected
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                // Create an image element
                var image = document.createElement('img');
                image.src = e.target.result;
                image.style.width = '200px'; // Set a specific width for the preview (adjust as needed)
                image.style.borderRadius = '10px'; // Set a specific width for the preview (adjust as needed)

                // Append the image to the preview div
                preview.appendChild(image);
            };

            // Read the selected file as a data URL
            reader.readAsDataURL(input.files[0]);
        }
    }
    
// TO POPULATE DATA FROM AN ENDPOINT 
function populateData(data){
    let valuesArray = Object.values(data);
            let keysArray = Object.keys(data);
            let mappedKeys = keysArray.map(function(key) {
                return key 
            });
            let mappedValues = valuesArray.map(function(val) {
                return val 
            });
            console.log(mappedKeys, mappedValues)
            for(let i=0;i<mappedKeys.length;i++){
                try{
                    if(document.getElementById(`${mappedKeys[i]}`))document.getElementById(`${mappedKeys[i]}`).value = mappedValues[i]
                }catch(err){
                    console.log(err)
                }
            }
}

// RESOLVING FORMDATA AND ACCOUNTING FOR ADDITIONAL DATA... NB:additional = [ ['id', 12], ['name', 'oreva'], ['age', 23] ]
const getFormData2 =(form=null, additional=[])=> {
    let formdata = new FormData(form)
    if(additional){
        for(let i=0;i<additional.length;i++){
            formdata.append(`${additional[i][0]}`, additional[i][1])
        }
    }
    formdata.forEach(function (value, key) {
        console.log(`${key}: ${value}`);
    });
    return formdata
} 

//TO SCROLL TO THE TOP
function scrollToTop(id=null) {
    if(id)document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
    window.scrollTo({
        top: 0,
        behavior: 'smooth' // You can use 'auto' or 'smooth' for scrolling behavior
    });
}


const checkdatalist =(element, id)=>{
    if(!element.value)return
    let list = element.list.id
    const datalistOptions = elementWithId(`${list}`).options
    const inputValue = element.value;
    
    let isMatch = false;
    for (let i = 0; i < datalistOptions.length; i++) {
        if (inputValue === datalistOptions[i].value) {
            isMatch = true;
            break;
        }
    }

    if (isMatch) {
        if(elementWithId(id))elementWithId(id).value = getLabelByValue(element.list.id, element.value)
        return true
    } else {
        notification(`${inputValue} is not a valid option`, 0);
        let ini = element.style.borderColor
        element.style.borderColor = 'red';
        element.style.color = 'red';
            element.value = '';
        setTimeout(()=>{
            element.style.borderColor = ini;
            element.style.color = 'black';
        },4000)
        if(elementWithId(id))elementWithId(id).value = ''
        return false
    }
}

function getLabelByValue(id, value) {
    const selectElement = document.getElementById(id);
    
    for (const option of selectElement.options) {
        if (option.value === value) {
            return option.text;
        }
    }

    // If the value is not found
    return null;
}


// LIST OF ALL THE COUNTRIES IN THE WORLD
const oreCountries = [
  "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda", "Argentina", "Armenia", "Australia", "Austria",
  "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bhutan", "Bolivia",
  "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cabo Verde", "Cambodia", "Cameroon",
  "Canada", "Central African Republic", "Chad", "Chile", "China", "Colombia", "Comoros", "Costa Rica", "Croatia", "Cuba", "Cyprus",
  "Czech Republic", "Democratic Republic of the Congo", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt",
  "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Eswatini", "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia",
  "Georgia", "Germany", "Ghana", "Greece", "Grenada", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Honduras", "Hungary",
  "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Ivory Coast", "Jamaica", "Japan", "Jordan", "Kazakhstan",
  "Kenya", "Kiribati", "Kosovo", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein",
  "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania",
  "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro", "Morocco", "Mozambique", "Myanmar (Burma)",
  "Namibia", "Nauru", "Nepal", "Netherlands", "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Korea", "North Macedonia", "Norway",
  "Oman", "Pakistan", "Palau", "Palestine", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Poland", "Portugal",
  "Qatar", "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino",
  "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands",
  "Somalia", "South Africa", "South Korea", "South Sudan", "Spain", "Sri Lanka", "Sudan", "Suriname", "Sweden", "Switzerland", "Syria", "Taiwan",
  "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu",
  "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City",
  "Venezuela", "Vietnam", "Yemen", "Zambia", "Zimbabwe"
];

function loadCountries(){
     if(document.getElementById('countrylist'))document.getElementById('countrylist').innerHTML = oreCountries.map(data=>`<option value="${data}"/>`).join('')
}
